// background/service-worker.js

chrome.runtime.onInstalled.addListener(() => console.log("[EFM] installed"));

async function activeTab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t || null;
}

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  const { type } = msg;

  // Content → popup relay
  if (type === "FOCUS_UPDATE") {
    chrome.runtime.sendMessage(msg).catch(() => {});
    respond({ ok: true });
    return false;
  }

  // Popup → content
  const forwardTypes = ["ACTIVATE_PICK","DEACTIVATE_PICK","CONFIRM_KEEP","APPLY_FOCUS","RESET"];
  if (forwardTypes.includes(type)) {
    activeTab().then(tab => {
      if (!tab) return respond({ ok: false });
      chrome.tabs.sendMessage(tab.id, msg, r => respond(r || { ok: true }));
    });
    return true;
  }

  respond({ ok: false, err: "unknown: " + type });
});
