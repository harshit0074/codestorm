// popup.js

const dot       = document.getElementById("dot");
const modeTitle = document.getElementById("mode-title");
const aiBadge   = document.getElementById("ai-badge");
const scoreNum  = document.getElementById("score-num");
const scoreLabel= document.getElementById("score-label");
const scoreBar  = document.getElementById("score-bar");
const aiReason  = document.getElementById("ai-reason");
const signals   = document.getElementById("signals");
const sigScroll = document.getElementById("sig-scroll");
const sigCursor = document.getElementById("sig-cursor");
const sigErr    = document.getElementById("sig-err");
const btnPick   = document.getElementById("btn-pick");
const btnConfirm= document.getElementById("btn-confirm");
const btnFocus  = document.getElementById("btn-focus");
const pickHint  = document.getElementById("pick-hint");
const chkImages = document.getElementById("chk-images");
const chkBigText= document.getElementById("chk-bigtext");

let picking = false;

function send(type, extra = {}) {
  return new Promise(resolve =>
    chrome.runtime.sendMessage({ type, ...extra }, r => resolve(r))
  );
}

function opts() {
  return { removeImages: chkImages.checked, enlargeText: chkBigText.checked };
}

// ── Pick mode ─────────────────────────────────────────────────────────────────
btnPick.addEventListener("click", async () => {
  picking = !picking;
  if (picking) {
    btnPick.textContent = "✕ Cancel";
    btnPick.classList.add("active");
    btnConfirm.classList.remove("hidden");
    pickHint.textContent = "Click elements on the page you want to KEEP.";
    await send("ACTIVATE_PICK");
  } else {
    btnPick.textContent = "☞ Select Elements to Keep";
    btnPick.classList.remove("active");
    btnConfirm.classList.add("hidden");
    pickHint.textContent = "Click areas on the page you want to keep. Everything else gets hidden.";
    await send("DEACTIVATE_PICK");
  }
});

btnConfirm.addEventListener("click", async () => {
  await send("CONFIRM_KEEP", { opts: opts() });
  btnPick.textContent = "☞ Select Elements to Keep";
  btnPick.classList.remove("active");
  btnConfirm.classList.add("hidden");
  btnPick.disabled = true;
  btnFocus.disabled = true;
  modeTitle.textContent = "EXTREME FOCUS";
  dot.className = "dot on";
  picking = false;
});

// ── Apply focus ───────────────────────────────────────────────────────────────
btnFocus.addEventListener("click", async () => {
  await send("APPLY_FOCUS", { opts: opts() });
  btnFocus.disabled = true;
  btnPick.disabled = true;
  modeTitle.textContent = "EXTREME FOCUS";
  dot.className = "dot on";
});

// ── Reset via storage change ──────────────────────────────────────────────────
chrome.storage.onChanged.addListener((changes) => {
  if (changes.focusReset?.newValue) {
    btnPick.disabled = false;
    btnFocus.disabled = false;
    btnPick.textContent = "☞ Select Elements to Keep";
    btnPick.classList.remove("active");
    btnConfirm.classList.add("hidden");
    pickHint.textContent = "Click areas on the page you want to keep. Everything else gets hidden.";
    modeTitle.textContent = "FOCUS MODE";
    dot.className = "dot";
    picking = false;
    chrome.storage.local.remove("focusReset");
  }
});

// ── Gemini focus updates ──────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== "FOCUS_UPDATE") return;
  const p = msg.payload;

  if (p.status === "waiting") {
    aiReason.textContent = "Collecting data — use the page (scroll, move mouse, type)...";
    return;
  }
  if (p.status === "ratelimit") {
    aiReason.textContent = "Rate limited (429) — waiting for next cycle (90s interval).";
    return;
  }
  if (p.status === "error") {
    aiReason.textContent = "Gemini error: " + p.msg;
    return;
  }

  const score = p.score ?? 0;
  scoreNum.textContent = score;
  scoreLabel.textContent = (p.label || "").toUpperCase();
  scoreBar.style.width = (score * 10) + "%";
  aiBadge.classList.remove("hidden");

  // Colour
  scoreNum.className = "score-num";
  scoreLabel.className = "score-label";
  if (score >= 7) {
    scoreNum.classList.add("hi"); scoreLabel.classList.add("hi");
    scoreBar.style.background = "#1a7a3a"; dot.className = "dot on";
  } else if (score >= 5) {
    scoreNum.classList.add("mid"); scoreLabel.classList.add("mid");
    scoreBar.style.background = "#b05000"; dot.className = "dot on";
  } else {
    scoreNum.classList.add("low"); scoreLabel.classList.add("low");
    scoreBar.style.background = "#c00"; dot.className = "dot low";
    modeTitle.textContent = "LOW FOCUS";
  }

  if (p.reason) aiReason.textContent = p.reason;

  // Signals
  if (p.signals) {
    signals.style.display = "flex";
    const s = p.signals;
    sigScroll.textContent = `scroll ${s.avg_scroll_speed}px/s`;
    sigCursor.textContent = `cursor ${s.avg_cursor_speed}px/s`;
    sigErr.textContent    = `errors ${(parseFloat(s.error_rate)*100).toFixed(0)}%`;
    sigScroll.className = "sig" + (p.signal === "scroll" ? " hot" : "");
    sigCursor.className = "sig" + (p.signal === "cursor" ? " hot" : "");
    sigErr.className    = "sig" + (p.signal === "error_rate" ? " hot" : "");
  }
});
