// content/injector.js — Extreme Focus Mode (clean rewrite)

(function () {
  "use strict";
  if (window.__EFM_LOADED__) return;
  window.__EFM_LOADED__ = true;

  const GEMINI_KEY = "AIzaSyAjDr4EUsDo6AFVoHJcHsWK6uQWNBWM0ZY";
  const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_KEY}`;

  // ── State ────────────────────────────────────────────────────────────────────
  let pickMode = false;
  let keptEls = new Set();
  let savedStyles = []; // [{el, style}]
  let focused = false;
  let aiLocked = false;
  let assessTimer = null;

  // ── Behavioral signals ───────────────────────────────────────────────────────
  let scrollSpeeds = [], lastScrollY = window.scrollY, lastScrollT = Date.now();
  let cursorSpeeds = [], lastMX = null, lastMY = null, lastMT = null;
  let totalKeys = 0, errorKeys = 0;
  let lastActive = Date.now(), idleAccum = 0;

  // ── Always inject reset button ───────────────────────────────────────────────
  injectResetBtn();
  startSignalCollection();
  startAIAssessment();

  // ── Message handler ──────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _, respond) => {
    if (msg.type === "ACTIVATE_PICK")    { activatePick(); respond({ ok: true }); }
    if (msg.type === "DEACTIVATE_PICK")  { deactivatePick(); respond({ ok: true }); }
    if (msg.type === "CONFIRM_KEEP")     { confirmKeep(msg.opts); respond({ ok: true }); }
    if (msg.type === "APPLY_FOCUS")      { applyFocus(msg.opts); respond({ ok: true }); }
    if (msg.type === "RESET")            { resetAll(); respond({ ok: true }); }
  });

  // ────────────────────────────────────────────────────────────────────────────
  // PICK MODE
  // ────────────────────────────────────────────────────────────────────────────
  function activatePick() {
    pickMode = true;
    document.body.style.cursor = "crosshair";
    document.addEventListener("mouseover", pickHover, true);
    document.addEventListener("mouseout",  pickOut,  true);
    document.addEventListener("click",     pickClick, true);
  }

  function deactivatePick() {
    pickMode = false;
    document.body.style.cursor = "";
    document.removeEventListener("mouseover", pickHover, true);
    document.removeEventListener("mouseout",  pickOut,  true);
    document.removeEventListener("click",     pickClick, true);
    document.querySelectorAll(".efm-hover").forEach(el => el.classList.remove("efm-hover"));
  }

  function pickHover(e) {
    const el = e.target;
    if (isEFM(el)) return;
    el.classList.add("efm-hover");
  }
  function pickOut(e) { e.target.classList.remove("efm-hover"); }
  function pickClick(e) {
    const el = e.target;
    if (isEFM(el)) return;
    e.preventDefault(); e.stopPropagation();
    if (keptEls.has(el)) {
      keptEls.delete(el);
      el.classList.remove("efm-kept");
    } else {
      keptEls.add(el);
      el.classList.add("efm-kept");
    }
  }

  // ────────────────────────────────────────────────────────────────────────────
  // CONFIRM KEEP — hide everything except chosen elements
  // ────────────────────────────────────────────────────────────────────────────
  function confirmKeep(opts) {
    deactivatePick();
    saveStyles();

    // Build set: kept elements + all their ancestors
    const keep = new Set(keptEls);
    keptEls.forEach(el => {
      let p = el.parentElement;
      while (p && p !== document.documentElement) { keep.add(p); p = p.parentElement; }
    });
    // Also keep descendants of kept elements
    keptEls.forEach(el => {
      el.querySelectorAll("*").forEach(d => keep.add(d));
    });

    // Hide everything not in keep set
    document.querySelectorAll("body *").forEach(el => {
      if (isEFM(el) || keep.has(el)) return;
      el.style.setProperty("display", "none", "important");
    });

    // Clean up markers
    keptEls.forEach(el => el.classList.remove("efm-kept"));

    // Apply optional extras
    applyOpts(opts);
    enterFocusMode();
  }

  // ────────────────────────────────────────────────────────────────────────────
  // APPLY FOCUS — smart "wikipedia mode": keep only main content, strip chrome
  // ────────────────────────────────────────────────────────────────────────────
  function applyFocus(opts) {
    saveStyles();

    // Find main content area intelligently
    const mainEl = findMainContent();

    // Hide everything on the page first
    // Then reveal only the main content + its ancestors
    const keep = new Set();
    if (mainEl) {
      keep.add(mainEl);
      // All descendants of main
      mainEl.querySelectorAll("*").forEach(el => keep.add(el));
      // All ancestors of main
      let p = mainEl.parentElement;
      while (p && p !== document.documentElement) { keep.add(p); p = p.parentElement; }
    }

    // Remove ALL sidebars, navs, footers, headers, ads, banners
    const STRIP_TAGS = ["header","footer","nav","aside","[role='banner']","[role='navigation']",
      "[role='complementary']","[role='contentinfo']",
      "ins","[class*='ad-']","[id*='ad-']","[class*='sidebar']","[id*='sidebar']",
      "[class*='widget']","[class*='footer']","[class*='header']",
      "[class*='nav']","[class*='menu']","[class*='cookie']","[class*='banner']",
      "[class*='popup']","[class*='modal']","[class*='overlay']",
      "[class*='recommend']","[class*='related']","[class*='trending']",
      "[class*='taboola']","[class*='outbrain']","[class*='sponsored']",
      "[class*='promo']","[class*='newsletter']","[class*='subscribe']",
      "[class*='share']","[class*='social']","[class*='comment']",
      "[class*='notification']","[class*='alert']","[class*='toast']",
      "[class*='floating']","[class*='sticky-']",
      "[id*='sidebar']","[id*='footer']","[id*='header']","[id*='nav']",
      "[id*='recommend']","[id*='related']","[id*='trending']",
      "ins.adsbygoogle"
    ];

    STRIP_TAGS.forEach(sel => {
      try {
        document.querySelectorAll(sel).forEach(el => {
          if (!mainEl || !mainEl.contains(el)) {
            el.style.setProperty("display", "none", "important");
          }
        });
      } catch(e) {}
    });

    // Also hide anything outside of main content that's not an ancestor
    if (mainEl) {
      document.querySelectorAll("body > *").forEach(el => {
        if (isEFM(el)) return;
        if (!keep.has(el)) {
          el.style.setProperty("display", "none", "important");
        }
      });
    }

    applyOpts(opts);
    enterFocusMode();
  }

  // Smart main content finder
  function findMainContent() {
    // Priority order: semantic tags, then score by text density
    const candidates = [
      document.querySelector("main"),
      document.querySelector("article"),
      document.querySelector("[role='main']"),
      document.querySelector("#content"),
      document.querySelector("#main-content"),
      document.querySelector("#article"),
      document.querySelector(".content"),
      document.querySelector(".article"),
      document.querySelector(".post-content"),
      document.querySelector(".entry-content"),
      document.querySelector(".story-body"),
      document.querySelector(".mw-parser-output"), // Wikipedia
      document.querySelector("#mw-content-text"),  // Wikipedia
    ].filter(Boolean);

    if (candidates.length > 0) return candidates[0];

    // Fallback: find element with most text that isn't body/html
    let best = null, bestScore = 0;
    document.querySelectorAll("div, section").forEach(el => {
      const text = (el.innerText || "").trim().length;
      const rect = el.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area < 10000) return; // too small
      const score = text / (el.querySelectorAll("*").length + 1);
      if (score > bestScore) { bestScore = score; best = el; }
    });
    return best || document.body;
  }

  function applyOpts(opts = {}) {
    if (opts.removeImages) {
      document.querySelectorAll("img, picture, video, iframe").forEach(el => {
        if (!isEFM(el)) el.style.setProperty("display", "none", "important");
      });
    }
    if (opts.enlargeText) {
      document.querySelectorAll("p, li, td, th, span, a, h1, h2, h3, h4").forEach(el => {
        const sz = parseFloat(getComputedStyle(el).fontSize);
        if (sz && sz < 20) el.style.setProperty("font-size", Math.max(sz * 1.25, 18) + "px", "important");
      });
    }
  }

  // ── Focus mode visuals ────────────────────────────────────────────────────────
  function enterFocusMode() {
    focused = true;
    document.body.classList.add("efm-active");
  }

  // ── Save / restore styles ─────────────────────────────────────────────────────
  function saveStyles() {
    if (savedStyles.length > 0) return; // already saved
    document.querySelectorAll("*").forEach(el => {
      savedStyles.push({ el, style: el.getAttribute("style") || null });
    });
  }

  function resetAll() {
    // Restore all original styles
    savedStyles.forEach(({ el, style }) => {
      if (style === null) el.removeAttribute("style");
      else el.setAttribute("style", style);
    });
    savedStyles = [];

    // Remove EFM classes
    document.querySelectorAll(".efm-kept,.efm-hover,.efm-active").forEach(el => {
      el.classList.remove("efm-kept","efm-hover","efm-active");
    });
    document.body.classList.remove("efm-active","efm-pick-active");
    document.body.style.cursor = "";

    // Reset state
    pickMode = false; focused = false; aiLocked = false;
    keptEls.clear();

    // Remove banner if any
    document.getElementById("efm-ai-banner")?.remove();

    chrome.storage.local.set({ focusReset: true });
  }

  // ── Reset button ──────────────────────────────────────────────────────────────
  function injectResetBtn() {
    if (document.getElementById("efm-reset-btn")) return;
    const btn = document.createElement("button");
    btn.id = "efm-reset-btn";
    btn.textContent = "↺ Reset";
    btn.onclick = (e) => { e.stopPropagation(); resetAll(); };
    document.body.appendChild(btn);
  }

  // ────────────────────────────────────────────────────────────────────────────
  // BEHAVIORAL SIGNAL COLLECTION
  // ────────────────────────────────────────────────────────────────────────────
  function startSignalCollection() {
    window.addEventListener("scroll", () => {
      const now = Date.now(), dt = (now - lastScrollT) / 1000;
      const dy = Math.abs(window.scrollY - lastScrollY);
      if (dt > 0 && dy > 0) { scrollSpeeds.push(dy / dt); if (scrollSpeeds.length > 60) scrollSpeeds.shift(); }
      lastScrollY = window.scrollY; lastScrollT = now;
      bumpActive(now);
    }, { passive: true });

    document.addEventListener("mousemove", (e) => {
      const now = Date.now();
      if (lastMX !== null) {
        const dist = Math.hypot(e.clientX - lastMX, e.clientY - lastMY);
        const dt = (now - lastMT) / 1000;
        if (dt > 0 && dt < 1) { cursorSpeeds.push(dist / dt); if (cursorSpeeds.length > 120) cursorSpeeds.shift(); }
      }
      lastMX = e.clientX; lastMY = e.clientY; lastMT = now;
      bumpActive(now);
    }, { passive: true });

    document.addEventListener("keydown", (e) => {
      totalKeys++;
      if (e.key === "Backspace" || e.key === "Delete") errorKeys++;
      bumpActive(Date.now());
    }, true);
  }

  function bumpActive(now) {
    const gap = now - lastActive;
    if (gap > 3000) idleAccum += gap;
    lastActive = now;
  }

  function avg(arr) { return arr.length ? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }

  function getSignals() {
    return {
      avg_scroll_speed: Math.round(avg(scrollSpeeds)),
      scroll_variance: Math.round(stdDev(scrollSpeeds)),
      avg_cursor_speed: Math.round(avg(cursorSpeeds)),
      cursor_variance: Math.round(stdDev(cursorSpeeds)),
      error_rate: totalKeys > 0 ? (errorKeys / totalKeys).toFixed(3) : "0",
      idle_s: ((idleAccum + Math.max(0, Date.now() - lastActive - 3000)) / 1000).toFixed(1),
    };
  }

  function stdDev(arr) {
    if (arr.length < 2) return 0;
    const m = avg(arr);
    return Math.sqrt(arr.reduce((a,b) => a + (b-m)**2, 0) / arr.length);
  }

  // ────────────────────────────────────────────────────────────────────────────
  // GEMINI AI ASSESSMENT (every 25 seconds)
  // ────────────────────────────────────────────────────────────────────────────
  function startAIAssessment() {
    assessTimer = setInterval(runGeminiAssessment, 90000); // 90s — well within free tier limits
  }

  async function runGeminiAssessment() {
    if (aiLocked) return;
    const s = getSignals();

    // Need some data
    if (scrollSpeeds.length < 2 && cursorSpeeds.length < 5) {
      chrome.runtime.sendMessage({ type: "FOCUS_UPDATE", payload: { status: "waiting", signals: s } });
      return;
    }

    const prompt = `You are a focus level analyzer. Assess a user's focus from behavioral data.

DATA (last 25 seconds):
- Scroll speed avg: ${s.avg_scroll_speed} px/s, variance: ${s.scroll_variance}
- Cursor speed avg: ${s.avg_cursor_speed} px/s, variance: ${s.cursor_variance}  
- Typing error rate: ${s.error_rate} (backspace ratio, 0=perfect, 1=all errors)
- Idle time: ${s.idle_s}s

RULES:
- Fast erratic scrolling (high speed + high variance) = distracted
- Slow steady scrolling = reading = focused
- High cursor speed + variance = restless
- High error rate = distracted/fatigued
- Long idle = disengaged

Respond ONLY with this exact JSON (no markdown):
{"score":7,"label":"Focused","low_focus":false,"reason":"Steady scrolling pace indicates reading","signal":"scroll"}

score: 1-10 (10=deeply focused, 1=totally distracted)
label: one of: Deep Focus | Focused | Mild Distraction | Distracted | Very Distracted
low_focus: true if score <= 4
reason: one short sentence
signal: dominant signal (scroll|cursor|error_rate|idle)`;

    // Only assess on the visible tab — avoids rate limits from multiple tabs
    if (document.visibilityState !== "visible") return;

    try {
      const res = await fetch(GEMINI_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 150 }
        })
      });

      // 429 = rate limited, back off and wait for next cycle
      if (res.status === 429) {
        chrome.runtime.sendMessage({ type: "FOCUS_UPDATE", payload: { status: "ratelimit", signals: s } });
        return;
      }

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
      // Strip any markdown fences
      const clean = text.replace(/```json|```/gi, "").trim();
      const result = JSON.parse(clean);

      chrome.runtime.sendMessage({
        type: "FOCUS_UPDATE",
        payload: { status: "ok", signals: s, ...result }
      });

      // Auto-trigger if low focus
      if (result.low_focus && !aiLocked && !focused) {
        aiLocked = true;
        applyFocus({});
        showAIBanner(result.score, result.reason);
      }

      // Reset signal buffers
      scrollSpeeds = []; cursorSpeeds = [];
      errorKeys = 0; totalKeys = 0;
      idleAccum = 0; lastActive = Date.now();

    } catch (err) {
      chrome.runtime.sendMessage({ type: "FOCUS_UPDATE", payload: { status: "error", msg: err.message, signals: s } });
    }
  }

  function showAIBanner(score, reason) {
    document.getElementById("efm-ai-banner")?.remove();
    const b = document.createElement("div");
    b.id = "efm-ai-banner";
    b.innerHTML = `<b>⬡ Focus Mode Auto-Activated</b><br><span style="font-size:11px;opacity:0.75">Score ${score}/10 — ${reason}</span><br><button onclick="this.parentElement.remove()" style="margin-top:8px;background:transparent;border:1px solid rgba(255,255,255,0.4);color:#fff;padding:3px 12px;font-size:10px;cursor:pointer;border-radius:2px;font-family:inherit">Dismiss</button>`;
    Object.assign(b.style, {
      position:"fixed", top:"16px", right:"16px", zIndex:"2147483647",
      background:"#111", color:"#fff", padding:"14px 16px", borderRadius:"4px",
      fontFamily:"-apple-system,sans-serif", fontSize:"13px", lineHeight:"1.5",
      border:"1px solid #333", boxShadow:"0 4px 20px rgba(0,0,0,0.5)",
      maxWidth:"260px", pointerEvents:"all"
    });
    document.body.appendChild(b);
    setTimeout(() => b.style.opacity = "0.2", 6000);
  }

  function isEFM(el) {
    return el.id?.startsWith("efm-") || el.closest?.("#efm-reset-btn") || el.closest?.("#efm-ai-banner");
  }

})();
